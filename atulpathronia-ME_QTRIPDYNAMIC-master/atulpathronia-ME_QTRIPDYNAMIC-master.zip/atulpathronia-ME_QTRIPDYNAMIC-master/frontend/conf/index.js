const config = { backendEndpoint: "http://3.7.198.32:8082" };

export default config;
